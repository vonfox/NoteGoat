# NoteGoat

A OneNote-style notes app: infinite folders, free-form pages, Kanban boards, spreadsheets and Markdown files, with local-first saving.

- `index.html` — the full app. Open it in a browser (works offline; saves to that browser).
- `notegoat-source.html` — the exact source published as the Claude artifact (no html/head wrapper). Edit this one.
- `docs/CONTEXT.md` — everything about the project: features, glossary, data model, decisions, version history.
- `docs/CLAUDE-HANDOFF.md` — prompt for continuing work in a new Claude session.

Live version (private): https://claude.ai/artifact/PDL4SSE8qH8LnzkSK1rN8W

Current version: 38.
