# NoteGoat — Full Project Context

*Snapshot: October 2, 2026 · Published version 38 · Owner: Vaughn*

NoteGoat is a OneNote-style notes app built around how Vaughn likes to work: infinite folders on the left, free-form note pages, Kanban boards, spreadsheets, Markdown files for AI instructions, and fast local-first saving with cloud sync.

- **Live app (private to Vaughn):** https://claude.ai/artifact/PDL4SSE8qH8LnzkSK1rN8W
- **Offline copy:** `app/NoteGoat.html` in this packet. Open it in any browser. It saves to that browser only (no cloud sync, no sign-in).
- **Source for future edits:** `app/notegoat-source.html`. This is the exact file that gets published (no `<html>/<head>` wrapper; the publisher adds that).

---

## 1. The vision (Vaughn's original brief)

| Topic | Answer |
|---|---|
| Platform | "Both / not sure yet" — web first, maybe desktop later |
| Keep from OneNote | Notebooks/sections/pages, free-form canvas, clipping & embeds |
| Improve on OneNote | Sync/speed issues; **infinite subfolders on the left**; **Kanban-like functions** |
| Storage | "Don't care, just start" |

### Working preferences learned along the way
- Prefers **simple, hands-on controls** over panels full of options (the detailed custom-palette editor was "too many options, very confusing" and was replaced with a random "Surprise me" generator).
- Wants **freedom of layout**: drag anything anywhere (pins, tabs, board columns, cards, note boxes).
- Likes being able to **switch between looks** rather than lose an old one (e.g. the Folder highlight setting keeps all three styles).
- Wants **everything in one left column** like OneNote's folder tree. A two-column layout (folders left, files right) was tried and **reverted at his request**.
- Wants a shared vocabulary for parts of the app (see the parts guide images and the glossary below).

---

## 2. Glossary — names for every part of the screen

Use these names when asking for changes.

| Name | What it is |
|---|---|
| **Sidebar / left menu** | The whole left column |
| **Logo** | The goat drawing + "NoteGoat" at top-left; the goat picture rotates and recolors with the palette |
| **+ New button** | Green button next to the logo |
| **Search box** | "Search everything — Ctrl K" |
| **Tabs (personas)** | Main, Main 2, etc. above the tree; each tab is its own separate notebook tree. Drag to reorder |
| **Pinned section** | Items pinned to the top of the tree. Drag to reorder |
| **Tree** | The folder/page list. Folders nest infinitely |
| **Row** | One line in the tree: caret, icon (emoji), title, pin button, ⋯ menu |
| **Trash** | Above the save status, bottom of sidebar |
| **Save status** | "Saved on this device only" / "Synced" |
| **A− / A+** | Sidebar text and icon size |
| **Breadcrumbs** | Path at the top of the main area (My Notebook / Getting started / Welcome) |
| **Top-right icons** | Undo, Redo, Download (Save as), Light/Dark, Appearance (palette) |
| **Toolbar** | The row under the breadcrumbs; changes per item type |
| **Canvas** | The free-form page area |
| **Note box** | A text block on the canvas (can be moved, snapped, linked, multi-selected) |
| **Board** | Kanban board: **columns** containing **cards**; columns sit in **lanes** (stacks) |
| **Card panel** | The right-side panel when you open a card |
| **Selection bar** | Floating bar at the bottom when several boxes or cards are selected |
| **Appearance popover** | Opened from the palette icon: Mode, Palette, Sidebar size, Folder highlight, Note text |

---

## 3. Everything the app does today

### Organizing
- **Infinite folders** in one left tree. Drag rows to move them before, after, or inside other rows.
- **Item types:** Folder, Page (free-form canvas), Board (Kanban), Table (spreadsheet), Markdown file.
- **Tabs (personas):** each tab is its own notebook tree, like OneNote notebooks. Add with +, rename by double-click, right-click for menu, **drag to reorder**.
- **Pinning:** pin button on every row (just before the ⋯). Pinned items appear in the Pinned section at the top; **drag to reorder**, or drag any tree item onto the Pinned section to pin it in that spot.
- **Emoji icons** for items and tabs (picker with search, categories, recents; opens on hover in menus).
- **Folder highlight** (Appearance → Folder highlight):
  - **Boxes** (default): box within a box for every folder above the open item.
  - **Shaded:** folders above fade level by level, with a small bar at each indent.
  - **Simple:** only the open item is highlighted.
- No vertical depth lines (removed by request); indentation still shows depth.
- **Trash** keeps deleted items 30 days: restore, delete forever, empty, or drag rows onto it.
- **Created / Last edited** timestamps on pages, tables, Markdown files.

### Pages (free-form canvas)
- Click anywhere to write; a blank page's first box starts at the "Click anywhere to write" hint.
- Boxes **push other boxes out of the way** and **snap** to a grid and to each other's edges.
- **Multi-select:** drag a box around boxes, Shift/Ctrl-click, Ctrl+A. Then copy, cut, duplicate, arrange, or delete (Delete/Backspace). Esc on a box selects it.
- **Arrange menu:** snap to grid, column, row, grid.
- **Linked boxes:** drag a box onto another page/folder in the sidebar → a synced copy is made there; edits stay in sync.
- **Text styling:** bold/italic/underline, checklists (Ctrl+1), ~30 fonts and many sizes (Ctrl+Shift+> / <), default font in Appearance.
- **Images:** right-click → insert from your computer, or drag files onto the page.
- **Middle-click autoscroll** (press the mouse wheel and move).

### Boards (Kanban)
- Columns hold cards; open a card for title, column, due date, label, **highlight**, notes, and "turn into a page."
- **Free column layout:** columns live in lanes (vertical stacks). Drop a column above/below another to stack it; drop near a column's left/right edge to make a new lane; **empty spots are kept as gaps**, so you can skip the first spot.
- Toolbar: **One row** (scroll sideways, default) or **Wrap** (wrap to new rows at the window edge), and **Close gaps**.
- Column ⋯ menu: Move left/right, Pull out into its own lane, Insert empty space before, Close empty gaps, Delete column (with Undo).
- **Multi-select cards:** Ctrl/Cmd-click, Shift-click a range, drag a box on empty board space, Ctrl+A. Selection bar: **Highlight** color, **Move to ▾**, **Group into column**, **Delete** (Delete/Backspace too, with Undo). Drag a selected card to move the whole group.

### Tables (spreadsheets)
- Formulas and formula bar, sort, freeze top row, bold/alignment, add rows/columns, undo/redo, copy/paste with Google Sheets and Excel, copy whole table, CSV.

### Markdown files
- Edit / Split / Preview modes. Templates for AI-friendly files (SOUL.md, SKILLS.md, instructions). Tabs do **not** auto-create SOUL.md (removed by request).

### Saving and exporting (Download icon or item menu → Save as…)
- Page → PDF, HTML, Markdown, TXT, Word (.docx)
- Table → Excel (.xlsx, keeps formulas), CSV, HTML, Markdown, PDF, Word
- Board → Excel, CSV, Markdown, HTML, PDF, Word
- Markdown file → MD, HTML, PDF, TXT, Word
- Folder or whole tab → ZIP of everything (HTML pages, XLSX tables/boards, MD files), one Word document, Markdown ZIP, one HTML, one PDF

### Look and feel
- Light / Dark / Auto mode.
- 10 palettes: Sage, Paper, Mist, Lilac, Rose, Graphite, Terracotta, Moss, Mauve, Cornflower. Alt+P cycles.
- **Surprise me:** random good-looking palettes; auto-named, rename and save; saved ones sit with the others.
- Goat logo changes picture every so often and recolors with the palette and light/dark.
- Sidebar size A−/A+ (Ctrl+Alt+= / Ctrl+Alt+−).
- Undo/Redo buttons and Ctrl+Z / Ctrl+Y across the app.

### Keyboard shortcuts
| Keys | Action |
|---|---|
| Ctrl+K | Search |
| Ctrl+Z / Ctrl+Y | Undo / Redo |
| Ctrl+A | Select all boxes (page) or cards (board) |
| Delete / Backspace | Delete selected boxes or cards |
| Esc | Clear selection / close panel |
| Ctrl+C / X / V / D | Copy / cut / paste / duplicate boxes |
| Ctrl+B / I / U | Bold / italic / underline |
| Ctrl+1 | Checklist |
| Ctrl+Shift+> / < | Bigger / smaller text |
| Alt+P | Next palette |
| Ctrl+Alt+= / − | Bigger / smaller sidebar |
| Middle mouse button | Autoscroll |

---

## 4. How it is built (for whoever works on it next)

- **One file**, plain HTML + CSS + JavaScript, no framework or build step. About 450 KB (the goat logos are embedded images).
- **Published as a Claude artifact** with capabilities `db`, `user`, `assets`, `downloads`. To update: edit the source and republish to the same URL (keep the capabilities).
- **Storage is local-first:** everything saves instantly to the browser (`localStorage`, keys `ng:<namespace>:...`), then syncs to the artifact database under `data/users/<userId>/` in two kinds of documents:
  - `tree` — all nodes (folders/items), tabs (`personas`), linked-box registry (`links`), trash, saved palettes (`themes`), preferences (`prefs`).
  - `p_<id>` — one document per page/board/table/Markdown file.
  - Conflicts are resolved by `updatedAt` and a per-session id.
- **Node** fields: `id, type (folder|page|board|md|sheet), title, parentId, order, persona, pinned (number = pin order), emoji, created, updated`.
- **Page data:** `blocks[] {id, x, y, w, h, html, ff (font), fs (size), syncId}`.
- **Board data:** `columns[] {id, title, lane, cards[] {id, title, label, hl, due, notes, pageId}}`, plus `wrap` (layout).
- **Table data:** `cells, rows, cols, w (widths), fmt, freeze`.
- **Theme:** CSS color tokens on `:root` with light/dark variants; palettes via `[data-palette]`; custom palettes as inline CSS variables.
- **Export libraries** load on demand from cdnjs: SheetJS 0.18.5, jsPDF 2.5.1, html2canvas 1.4.1, JSZip 3.10.1. Word files are written directly as OOXML.
- **Per-device settings** (not synced): folder highlight style, sidebar size, sidebar width, Markdown view mode, default note font.

---

## 5. Decisions and things that were reverted

| Decision | Why |
|---|---|
| Single left tree (no separate files column) | Two-column OneNote-style layout was built (v28), then reverted at Vaughn's request |
| Tabs are plain notebooks | Auto-created SOUL.md in new tabs was removed; AI .md files are added by choice |
| "Surprise me" random palettes instead of a full color editor | Full editor was too confusing |
| Depth lines removed from tree | Requested; depth now shown by indent + Folder highlight |
| Board default = One row | Wrap-only felt limiting; both offered |
| Note box outlines kept faint | Requested lighter, less prominent boxes |

---

## 6. Known limits

- **PDF exports are images** of the content (text in them isn't selectable or searchable).
- **Custom "Surprise me" palettes** don't switch with light/dark mode.
- On **phones**, the layout keeps the single tree; not tuned deeply for mobile yet.
- The **offline copy** in this packet saves only to the browser it's opened in; the live artifact is where cloud sync works.
- Downloads and export libraries need internet the first time (they load from cdnjs).
- The **parts guide images** are from early versions (about v4); later parts (tabs, pins, trash, A−/A+, Appearance options, board toolbar) are named in the glossary above instead.

---

## 7. Ideas not built yet

- Desktop app packaging.
- Tags and backlinks between pages.
- Page templates.
- Import from OneNote or Markdown folders.
- AI features that read the SOUL.md / SKILLS.md files in a tab.
- Updated parts-guide image showing the current layout.
- Better phone layout.

---

## 8. Version history (newest first)

| Version | What changed |
|---|---|
| 38 | Folder highlight setting: Boxes / Shaded / Simple |
| 37 | Box-within-a-box highlight for folders above the open item |
| 36 | Shaded highlight of the open item's folder chain |
| 35 | Removed vertical depth lines from the tree |
| 34 | Board cards: multi-select, highlight colors, Move to, Group into column, delete, group drag |
| 33 | Board columns: free lanes with gaps, One row / Wrap, Close gaps, column menu moves |
| 32 | Board columns can stack vertically |
| 31 | Drag to reorder tabs |
| 30 | Drag to reorder pinned items |
| 29 | Reverted the two-column layout back to a single left tree |
| 28 | (Reverted) Separate files column on the right of the folders |
| 27 | Sidebar size A−/A+ |
| 26 | Undo/Redo buttons + Ctrl+Z/Ctrl+Y |
| 25 | Delete selected box with Delete/Backspace |
| 22–24 | Palette maker → hands-on mockup editor → replaced by "Surprise me" random palettes |
| 21 | Four extra palettes (Terracotta, Moss, Mauve, Cornflower) |
| 20 | Word (.docx) export; right-click to insert images from computer |
| 19 | Save as / export in many formats |
| 18 | Fonts and sizes, Trash, hover submenus |
| 16–17 | Hover-to-open icon picker; first box starts at the hint; softer box outlines |
| 15 | Created + Last edited timestamps |
| 14 | Emoji icons; pin button on each row |
| 13 | Middle-click autoscroll |
| 12 | Multi-select note boxes, Arrange menu |
| 11 | Linked (synced) note boxes across pages |
| 10 | Goat logo that rotates and recolors |
| 9 | Tables (spreadsheets) |
| 8 | Tabs as plain notebooks; SKILLS.md template |
| 5–7 | Tabs (personas), pinning, Markdown files, light/dark + palettes, two-level header |
| 1–4 | Infinite tree, free-form pages, Kanban boards, local-first sync, push-aside boxes, snapping |
