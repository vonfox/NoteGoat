# Prompt to start a new Claude session on NoteGoat

Copy everything in the box below into a new chat. Attach `NoteGoat-Context.md` and `app/notegoat-source.html` from this packet.

```
I'm continuing work on NoteGoat, my OneNote-style notes app. The attached
NoteGoat-Context.md explains everything: the vision, the names I use for
each part of the screen, every feature, how it's built, decisions I've made,
known limits and version history. The attached notegoat-source.html is the
current app (version 38).

How I like to work:
- Make changes directly to the single HTML file and keep everything in it.
- Test changes before handing them back, and tell me briefly what changed.
- Keep controls simple and hands-on; I don't want panels full of options.
- When you change how something looks, keep the old look available as an
  option if it's a matter of taste.
- Keep everything in one left-hand tree (no separate files column).

The live app is a Claude artifact:
https://claude.ai/artifact/PDL4SSE8qH8LnzkSK1rN8W
If you can publish artifacts, update that same URL and keep its
capabilities (db, user, assets, downloads). If you can't, give me the
updated HTML file.

First, read the context file and confirm you understand where things stand.
Then here's what I want next:
[describe your next change here]
```

## Tips
- Use the glossary names (Sidebar, Tabs, Pinned section, Row, Toolbar, Canvas, Note box, Board, Lane, Card, Selection bar, Appearance popover) so Claude knows exactly which part you mean.
- After a session that adds features, ask Claude to update `NoteGoat-Context.md` (features, version history) so this packet stays current.
